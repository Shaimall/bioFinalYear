/*
 * Created by dev on: 10.12.2023
 */
package GA_Bin;

/**
 *
 * @author shaimal
 */
public class Data {
    public int size;
    public int[] variables;
    public int output;

    public Data(int size) {
        this.size = size;
        this.variables = new int[size];
    }

    public void setOutput(int output) {
        this.output = output;
    }

    public int getOutput() {
        return output;
    }

    public int[] getVariables() {
        return variables;
    }

    public String printVariables() {
        String str = "";
        for (int gene : variables) {
            str = str + gene;
        }
        return str;
    }

}
