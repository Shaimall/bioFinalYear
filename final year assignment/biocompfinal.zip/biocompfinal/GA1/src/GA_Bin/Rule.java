
package GA_Bin;

/**
 *
 * @author shaimal
 */
public class Rule {
    public int condLength;
    public String[] cond;
    public String output;

    public Rule(int condLength) {
        this.condLength = condLength;
        this.cond = new String[condLength];
        this.output = "";
    }

    public String[] getCond() {
        return cond;
    }
    
    
}
